import React from 'react';
interface LandpadsTableProps {
    landpads: any[];
  }

const LandpadsTable:React.FC<LandpadsTableProps>  = ({ landpads }) => {
  return (
    <div className="landpads-container">
      <h2>Launchpads Information</h2>
      {landpads.map((landpad: any) => (
        <div key={landpad.id} className="landpad-card">
          <h3 className="landpad-name">{landpad.full_name}</h3>
          <table className="landpad-table">
            <thead>
              <tr>
                <th>Property</th>
                <th>Value</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>ID</td>
                <td>{landpad.id}</td>
              </tr>
              <tr>
                <td>Details</td>
                <td>{landpad.details}</td>
              </tr>
              <tr>
                <td>Status</td>
                <td>{landpad.status}</td>
              </tr>
              {/* Add more rows for other properties as needed */}
            </tbody>
          </table>
          <div className="landpad-links">
            <h4>Links</h4>
            <ul>
              <li>
                Wikipedia: <a href={landpad.wikipedia} target="_blank" rel="noopener noreferrer">{landpad.wikipedia}</a>
              </li>
            </ul>
          </div>
        </div>
      ))}
    </div>
  );
};

export default LandpadsTable;