import React, { useState } from "react";
import { DocumentNode, useQuery } from "@apollo/client";
import { useParams } from "react-router-dom";
import { gql } from "@apollo/client";
import LaunchDetailsTable from "./LaunchDetailsTable";
import LandpadsTable from "./LandpadsTable";
import UpcomingLaunchesComponent from "./UpcomingLaunchesComponent ";

interface QueryEvents {
  LAUNCH_PADS: DocumentNode;
  LAUNCHES: DocumentNode;
  UPCOMING_LAUNCHES: DocumentNode;
  CAPSULE_INFORMATION: DocumentNode;
  COMPANY_INFORMATION: DocumentNode;
}

const QUERY_EVENTS: QueryEvents = {
  LAUNCH_PADS: gql`
    query GetLaunchPads {
      launchpads {
        attempted_launches
        details
        id
        location {
          latitude
          longitude
          name
          region
        }
        name
        status
        successful_launches
         
        wikipedia
      }
    }
  `,
  LAUNCHES: gql`
    query GetLaunches {
      launches {
        details
        id
        is_tentative
        launch_date_local
        launch_date_unix
        launch_date_utc
        launch_success
        launch_year
        links {
          article_link
          flickr_images
          mission_patch
          mission_patch_small
          presskit
          reddit_campaign
          reddit_launch
          reddit_media
          reddit_recovery
          video_link
          wikipedia
        }
        mission_id
        mission_name
        rocket {
          rocket_name
          rocket_type
        }
        static_fire_date_unix
        static_fire_date_utc
        tentative_max_precision
        upcoming
        launch_site {
          site_id
          site_name
          site_name_long
        }
      }
    }
  `,
  UPCOMING_LAUNCHES: gql`
    query GetUpcomingLaunches {
        launchesUpcoming {
            details
            id
            is_tentative
            launch_date_local
            launch_date_unix
            launch_date_utc
            
            launch_success
            launch_year
            
            mission_id
            mission_name
            rocket {
              rocket_name
              rocket_type
            }
            
            static_fire_date_unix
            static_fire_date_utc
            
            tentative_max_precision
            upcoming
          }
    }
  `,
  CAPSULE_INFORMATION: gql`
    query GetCapsuleInformation {
        capsules {
            dragon {
              description
              id
              name
            }
            id
            landings
            missions {
              flight
              name
            }
            original_launch
            reuse_count
            status
            type
          }
    }
  `,
  COMPANY_INFORMATION: gql`
    query GetCompanyInformation {
      company {
        name
        founder
        founded
        employees
      }
    }
  `,
};

const getQuery = (event: keyof QueryEvents): DocumentNode => {
  switch (event) {
    case "LAUNCH_PADS":
      return QUERY_EVENTS.LAUNCH_PADS;
    case "LAUNCHES":
      return QUERY_EVENTS.LAUNCHES;
    case "UPCOMING_LAUNCHES":
      return QUERY_EVENTS.UPCOMING_LAUNCHES;
    case "CAPSULE_INFORMATION":
      return QUERY_EVENTS.CAPSULE_INFORMATION;
    case "COMPANY_INFORMATION":
      return QUERY_EVENTS.COMPANY_INFORMATION;
    default:
      throw new Error(`Unknown event: ${event}`);
  }
};

const getDataQuery = (event: any): any => {
  switch (event) {
    case "LAUNCH_PADS":
      return "launchpads";
    case "LAUNCHES":
      return "launches";
    case "UPCOMING_LAUNCHES":
      return "launchesUpcoming";
    case "CAPSULE_INFORMATION":
      return "capsules";
    case "COMPANY_INFORMATION":
      return "company";
    default:
      throw new Error(`Unknown event: ${event}`);
  }
};

const QueryComponent = () => {
  const [selectedEvent, setSelectedEvent] = useState("LAUNCH_PADS"); // Default to Launch Pads

  // Fetch GraphQL query based on the selected event
  const { loading, error, data } = useQuery(getQuery(selectedEvent as any));

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error.message}</p>;

  return (
    <div>
      <h2>{selectedEvent} Information</h2>

      {/* Event Selection Dropdown */}
      <div>
        <label>Select Event:</label>
        <select onChange={(e) => setSelectedEvent(e.target.value)}>
          {Object.keys(QUERY_EVENTS).map((eventKey) => (
            <option key={eventKey} value={eventKey}>
              {eventKey}
            </option>
          ))}
        </select>
      </div>

      <div>
        {selectedEvent === "LAUNCHES" ? (
          <div>
            <LaunchDetailsTable launches={data[getDataQuery(selectedEvent)]} />
          </div>
        ) : (
          <div></div>
        )}
      </div>

      <div>
        {selectedEvent === "LAUNCH_PADS" ? (
         <div>
         <LandpadsTable  landpads={data[getDataQuery(selectedEvent)]} />
       </div>
        ) : (
          <div></div>
        )}
      </div>

      <div>
        {selectedEvent === "UPCOMING_LAUNCHES" ? (
         <div>
         <UpcomingLaunchesComponent   launches={data[getDataQuery(selectedEvent)]} />
       </div>
        ) : (
          <div></div>
        )}
      </div>

    </div>
  );
};

export default QueryComponent;
