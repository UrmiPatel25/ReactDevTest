import React from 'react';

const UpcomingLaunchesComponent = ({ launches }) => {
  return (
    <div>
      <h2>Upcoming Launches</h2>
      <div className="launches-container">
        {launches.map((launch) => (
          <div key={launch.id} className="launch-card">
            <h3>{launch.mission_name}</h3>
            <p>
              <strong>Launch Date:</strong>{' '}
              {new Date(launch.launch_date_utc).toLocaleDateString()}{' '}
              {new Date(launch.launch_date_utc).toLocaleTimeString()}
            </p>
            <p>
              <strong>Rocket:</strong> {launch.rocket.rocket_name}
            </p>
            <p>
              <strong>Details:</strong> {launch.details || 'No details available'}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default UpcomingLaunchesComponent;