
import React from 'react';
import { useSelector } from 'react-redux';

const ReportsComponent: React.FC = () => {
  const reports = useSelector((state: any) => state.reports); // Assuming you have a 'reports' slice in your Redux store

  return (
    <div>
      <h2>Reports</h2>
      {reports.length === 0 ? (
        <p>No reports available.</p>
      ) : (
        <ul className="reports-list">
          {reports.map((report) => (
            <li key={report.id} className="report-item">
              <h3>Report ID: {report.id}</h3>
              <p>Content: {report.content}</p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default ReportsComponent;