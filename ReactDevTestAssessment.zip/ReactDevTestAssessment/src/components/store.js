// store.js
import { createStore } from 'redux';
import reportReducer from './reportReducer';

const store = createStore(reportReducer);

export default store;