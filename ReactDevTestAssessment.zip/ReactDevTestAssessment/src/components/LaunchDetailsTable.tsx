import React from 'react';
// Define an interface for the component props
interface LaunchDetailsTableProps {
    launches: any[];
  }
const LaunchDetailsTable  :React.FC<LaunchDetailsTableProps> = ({ launches }) => {
  return (
    <div className="launch-details-container">
      <h2 className="launch-details-title">Launch Details</h2>
      {launches.map((launch) => (
        <div key={launch.id} className="launch-card">
          <h3 className="mission-name">{launch.mission_name}</h3>
          <table className="launch-table">
            <thead>
              <tr>
                <th>Property</th>
                <th>Value</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>ID</td>
                <td>{launch.id}</td>
              </tr>
              <tr>
                <td>Mission Name</td>
                <td>{launch.mission_name}</td>
              </tr>
              <tr>
                <td>Launch Year</td>
                <td>{launch.launch_year}</td>
              </tr>
              {/* Add more rows for other properties as needed */}
            </tbody>
          </table>
          <div className="launch-links">
            <h4>Links</h4>
            <ul>
              <li>
                Article Link: <a href={launch.links.article_link} target="_blank" rel="noopener noreferrer">{launch.links.article_link}</a>
              </li>
              <li>
                Video Link: <a href={launch.links.video_link} target="_blank" rel="noopener noreferrer">{launch.links.video_link}</a>
              </li>
              <li>
                Wikipedia: <a href={launch.links.wikipedia} target="_blank" rel="noopener noreferrer">{launch.links.wikipedia}</a>
              </li>
              {/* Add more links as needed */}
            </ul>
          </div>
        </div>
      ))}
    </div>
  );
};

export default LaunchDetailsTable;