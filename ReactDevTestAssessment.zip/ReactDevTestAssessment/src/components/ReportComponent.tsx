// src/components/ReportComponent.tsx
import React from 'react';
import { FieldError, useForm } from 'react-hook-form';
import { useDispatch } from 'react-redux';
import { addReport } from './reportsSlice';

const ReportComponent: React.FC = () => {
  const { register, handleSubmit, formState: { errors } } = useForm();
  const dispatch = useDispatch();

  const onSubmit = (data: { title: string; description: string; category: string }) => {
    dispatch(addReport({
      id: Date.now().toString(),
      content: JSON.stringify(data),
    }));
  };

  return (
    <div>
      <h2>File a Report</h2>
      <form className="report-form" onSubmit={handleSubmit(onSubmit)}>
        <div>
          <label htmlFor="title">Title</label>
          <input className="form-input"  {...register('title', { required: 'Title is required' })} />
          <span className="error-message">{(errors.title as FieldError)?.message}</span>
        </div>
        <div>
          <label  htmlFor="description">Description</label>
          <textarea className="form-input"  {...register('description', { required: 'Description is required' })} />
          <span className="error-message">{(errors.description as FieldError)?.message}</span>
        </div>
        <div>
          <label htmlFor="category">Category</label>
          <input className="form-input"  {...register('category', { required: 'Category is required' })} />
          <span className="error-message">{(errors.category as FieldError)?.message}</span>
        </div>
        <button type="submit">Submit Report</button>
      </form>
    </div>
  );
};

export default ReportComponent;