import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface Report {
  id: string;
  content: string;
}

interface ReportsState {
  reports: Report[];
}

const initialState: ReportsState = {
  reports: [],
};

const reportsSlice = createSlice({
  name: 'reports',
  initialState,
  reducers: {
    addReport: (state: any, action: PayloadAction<Report>) => {
      state.reports.push(action.payload);
    },
  },
});

export const { addReport } = reportsSlice.actions;
export default reportsSlice.reducer;