import React from 'react';
import './App.css';
import { ApolloClient, InMemoryCache, ApolloProvider } from '@apollo/client';
 import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import QueryComponent from './components/QueryComponent';
import reportsReducer from './components/reportsSlice';
import ReportComponent from './components/ReportComponent';
import { Provider } from 'react-redux';
import { ThunkAction, configureStore } from '@reduxjs/toolkit';
import { Action, combineReducers } from 'redux';
import ReportsComponent from './components/ReportsComponent';

const client = new ApolloClient({
  uri: 'https://spacex-production.up.railway.app/',
  cache: new InMemoryCache(),
});


// Define RootState type
type RootState = ReturnType<typeof rootReducer>;

// Create rootReducer by combining reducers
const rootReducer = combineReducers({
  reports: reportsReducer,
});

// Define AppThunk type for thunks
type AppThunk<ReturnType = void> = ThunkAction<ReturnType, RootState, unknown, Action<string>>;

// Create store with rootReducer and any middleware you might need
const store = configureStore({
  reducer: rootReducer,
});

const App: React.FC = () => {
  return (

    <Provider store={store}>
       <ApolloProvider client={client}>
      <Router>
        <Routes>
          <Route path="/query" element={<QueryComponent />} />
          <Route path="/report" element={<ReportComponent />} />
          <Route path="/reports" element={<ReportsComponent />} />
        </Routes>
      </Router>
    </ApolloProvider>
    </Provider>


   
  );
};

export default App;
 
